package com.example.news.ui.theme

import androidx.compose.ui.unit.sp

val textSize1 = 1.sp
val textSize2 = 2.sp
val textSize3 = 3.sp
val textSize4 = 4.sp
val textSize5 = 5.sp
val textSize6 = 6.sp
val textSize7 = 7.sp
val textSize8 = 8.sp
val textSize9 = 9.sp
val textSize10 = 10.sp
val textSize11 = 11.sp
val textSize12 = 12.sp
val textSize13 = 13.sp
val textSize14 = 14.sp
val textSize15 = 15.sp
val textSize16 = 16.sp
val textSize17 = 17.sp
val textSize18 = 18.sp
val textSize19 = 19.sp
val textSize20 = 20.sp
val textSize21 = 21.sp
val textSize22 = 22.sp
val textSize23 = 23.sp
val textSize24 = 24.sp
val textSize25 = 25.sp
val textSize26 = 26.sp
val textSize27 = 27.sp
val textSize28 = 28.sp
val textSize29 = 29.sp
val textSize30 = 30.sp
val textSize32 = 32.sp